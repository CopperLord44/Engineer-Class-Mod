﻿

using EngineerClassMod.Items.EngineerClass;
using EngineerClassMod.Items.EngineerClass.Attachments;
using EngineerClassMod.UI;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace EngineerClassMod.Items
{

    public class EngineerGlobalItem : GlobalItem
    {
        

        public override bool CanRightClick(Item item)
        {
            if (ModContent.GetInstance<EngineerClassMod>()._DisUI.CurrentState != null && item.damage > 0 && item.maxStack == 1) { return true; }
            var itemClone = item.Clone();
            if (itemClone.modItem == null) { return false; }
            ModItem mouseItemObject = itemClone.modItem;


            ModItem MI = mouseItemObject as ModItem;
            EngineerAttachments EA = MI as EngineerAttachments;

            if (EA == null || !Main.LocalPlayer.GetModPlayer<EngineerPlayer>().EngineerWeapon) { return false; }

            return true;
        }

        public override void RightClick(Item item, Player player)
        {
            Item itemClone = item.Clone();
            if (ModContent.GetInstance<EngineerClassMod>()._DisUI.CurrentState != null && item.damage > 0 && item.maxStack == 1 && !item.favorited)
            {
                for (int i = 0; i < 24; i++)
                {

                    if (ModContent.GetInstance<EngineerClassMod>().disassembleUI.itemslots[i] == null || ModContent.GetInstance<EngineerClassMod>().disassembleUI.itemslots[i].type == ItemID.None)
                    { ModContent.GetInstance<EngineerClassMod>().disassembleUI.itemslots[i] = itemClone; return; }
                }
                Item.NewItem(player.position, new Vector2(player.height, player.width), itemClone.type, 1, false, itemClone.prefix, false, false);

            }

            if (itemClone.modItem != null)
            {
                ModItem MI = itemClone.modItem;



                EngineerAttachments EA = MI as EngineerAttachments;

                if (EA != null && ModContent.GetInstance<EngineerClassMod>()._EngineerGun.CurrentState != null && EA.attachmentFor == EngineerAttachments.Rifle)
                {
                    if(player.GetModPlayer<EngineerPlayer>().attachments[EA.attachmentPlace] != null) { player.QuickSpawnItem(player.GetModPlayer<EngineerPlayer>().attachments[EA.attachmentPlace]); }
                    player.GetModPlayer<EngineerPlayer>().attachments[EA.attachmentPlace] = itemClone;
                    return;
                }
            }
            Item.NewItem(player.position, new Vector2(player.height, player.width), itemClone.type, 1, false, itemClone.prefix, false, false);
        }
        
        
    }
}
