﻿
using EngineerClassMod.UI;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using Terraria;
using Terraria.GameContent.UI;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;


namespace EngineerClassMod
{
    public class EngineerClassMod : Mod
    {
       

       
        internal EngineerAmmoBar EngineerAmmoBar;
        
        internal EngineerGun EngineerGun;
        internal DisassembleUI disassembleUI;
        
        private UserInterface _engineerAmmoBar;
        
        public UserInterface _EngineerGun;
        public UserInterface _DisUI;

        
        public override void Load()
        {
            

            

          
            EngineerAmmoBar = new EngineerAmmoBar();
            EngineerAmmoBar.Activate();
            

            EngineerGun = new EngineerGun();
            EngineerGun.Activate();
            disassembleUI = new DisassembleUI();
            disassembleUI.Activate();
            _EngineerGun = new UserInterface();
            _EngineerGun.SetState(EngineerGun);
            _engineerAmmoBar = new UserInterface();
            _engineerAmmoBar.SetState(EngineerAmmoBar);

            
            _DisUI = new UserInterface();
            _DisUI.SetState(null);

        }
       
        public override void UpdateUI(GameTime gameTime)
        {
           
            _engineerAmmoBar?.Update(gameTime);
            EngineerAmmoBar?.Update(gameTime);
            
            

            _EngineerGun?.Update(gameTime);
            EngineerGun?.Update(gameTime);
            _DisUI?.Update(gameTime);
            disassembleUI?.Update(gameTime);
        }
        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            int resourceBarIndex = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Resource Bars"));
            if (resourceBarIndex != -1)
            {
                layers.Insert(resourceBarIndex, new LegacyGameInterfaceLayer(
                    "DRGN: Resouce Bars",
                    delegate
                    {
                        
                        _EngineerGun.Draw(Main.spriteBatch, new GameTime());
                        _engineerAmmoBar.Draw(Main.spriteBatch, new GameTime());
                        _DisUI.Draw(Main.spriteBatch, new GameTime());
                       

                        return true;
                    },
                    InterfaceScaleType.UI)
                );
            }
        }


        


    }

}