﻿using EngineerClassMod.Items.EngineerClass;
using EngineerClassMod.Items.EngineerClass.Attachments;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Web;
using Terraria;
using Terraria.GameContent.UI.Elements;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;

namespace EngineerClassMod.UI
{
    class EngineerGun : UIState
    {
        private UIPanel panel;
        private UIPanel[] slots = new UIPanel[6];
        private bool killItem;
        private UIPanel openButton;
        public bool shouldShow;
        private Player player;
        private Item[] itemSlots = new Item[6];
        private Vector2[] slotsPos = new Vector2[6]
        {
            new Vector2(30,118),
            new Vector2(220,124),
            new Vector2(110,22),
            new Vector2(74,168),
            new Vector2(118,168),
            new Vector2(10,66),
        };
        public override void OnInitialize()
        {
            panel = new UIPanel(); // 2
            panel.Left.Pixels = 585;
            panel.Top.Set(20, 0);
            panel.Width.Set(280, 0);
            panel.Height.Set(240, 0);
            openButton = new UIPanel(); // 2
            openButton.Left.Pixels = 535;
            openButton.Top.Set(20, 0);
            openButton.Width.Set(38, 0);
            openButton.Height.Set(38, 0);
            openButton.OnClick += OnButtonClick;
            for (int i = 0; i < 6; i++)
            {
                slots[i] = new UIPanel();

                slots[i].Left.Set(slotsPos[i].X, 0);
                slots[i].Top.Set(slotsPos[i].Y, 0);
                slots[i].Width.Set(38, 0);
                slots[i].Height.Set(38, 0);
                slots[i].OnClick += OnButtonClick;
                slots[i].OnRightClick += OnRightMB;
                panel.Append(slots[i]);
            }
            Append(panel);
            Append(openButton);
            shouldShow = true;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            if (Main.playerInventory && player.GetModPlayer<EngineerPlayer>().EngineerWeapon)
            {
                Texture2D[] defaultTextures = new Texture2D[6] 
                {
                    Main.itemTexture[ModContent.ItemType<GunBody1>()] ,
                    Main.itemTexture[ModContent.ItemType<GunBarrel1>()] ,
                    Main.itemTexture[ModContent.ItemType<GunScope1>()] ,
                    Main.itemTexture[ModContent.ItemType<GunGrip1>()] ,
                    Main.itemTexture[ModContent.ItemType<GunMag1>()] ,
                    Main.itemTexture[ModContent.ItemType<GunChamber1>()] ,
                };
            
                int gunStartX = (int)(panel.Left.Pixels + 79);
                int gunStartY = (int)(panel.Top.Pixels + 84);
                Texture2D accSlot = ModContent.GetTexture("EngineerClassMod/UI/AccessorySlot");
                Texture2D panelSlot = ModContent.GetTexture("EngineerClassMod/UI/PanelSlot");
                Vector2[] baseOffsets = new Vector2[6]
                {
                    new Vector2(gunStartX, gunStartY + 20),
                    new Vector2(gunStartX + 74, gunStartY + 24),
                    new Vector2(gunStartX + 2, gunStartY),
                    new Vector2(gunStartX + 8, gunStartY + 52),
                    new Vector2(gunStartX + 40, gunStartY + 52),
                    new Vector2(gunStartX + 14, gunStartY + 28)
                };
                spriteBatch.Draw(accSlot, new Vector2(openButton.Left.Pixels, openButton.Top.Pixels), new Rectangle(0, 0, 38, 38), Color.White);
                if (shouldShow)
                {
                    spriteBatch.Draw(panelSlot, new Vector2(panel.Left.Pixels, panel.Top.Pixels), new Rectangle(0, 0, 280, 240), Color.White);
                    for (int i = 0; i < 6; i++)
                    {
                        bool drawDefault = true;
                        spriteBatch.Draw(accSlot, new Vector2(panel.Left.Pixels + slots[i].Left.Pixels, panel.Top.Pixels + slots[i].Top.Pixels), new Rectangle(0, 0, 38, 38), Color.White);
                        if (itemSlots[i] != null)
                        {
                            ModItem mi = itemSlots[i].modItem;
                            if (mi != null)
                            {
                                EngineerAttachments ea = mi as EngineerAttachments;
                                if (ea != null)
                                {
                                    Texture2D text = Main.itemTexture[itemSlots[i].type];

                                    if (text != null)
                                    {
                                        Vector2 slotPosition = new Vector2(panel.Left.Pixels + slots[i].Left.Pixels + (accSlot.Width - text.Width) / 2, panel.Top.Pixels + slots[i].Top.Pixels + (accSlot.Height - text.Height) / 2);


                                        if (ea.shouldOffset) { baseOffsets[i] += ea.drawOffset; }
                                        spriteBatch.Draw(text, baseOffsets[i], new Rectangle(0, 0, text.Width, text.Height), Color.White, 0, Vector2.Zero, 2f, SpriteEffects.None, 0);
                                        spriteBatch.Draw(text, slotPosition, new Rectangle(0, 0, text.Width, text.Height), Color.White);
                                        drawDefault = false;
                                    }
                                }
                            }
                        }
                        if (drawDefault)
                        {

                            spriteBatch.Draw(defaultTextures[i], baseOffsets[i], new Rectangle(0, 0, defaultTextures[i].Width, defaultTextures[i].Height), Color.White, 0, Vector2.Zero, 2f, SpriteEffects.None, 0);
                        }
                    }
                }
                
            }
        }
        public void OnButtonClick(UIMouseEvent evt, UIElement listeningElement)
        {
            if(listeningElement == openButton)
            { shouldShow = !shouldShow; }
            killItem = true;
            var mouseItemClone = Main.mouseItem.Clone();
            if (mouseItemClone.modItem == null) { killItem = false; return; }
            ModItem MI = mouseItemClone.modItem;           
            EngineerAttachments EA = MI as EngineerAttachments;
            if (EA == null) { killItem = false; return; }
            if (listeningElement == slots[EA.attachmentPlace])
            {
                if (itemSlots[EA.attachmentPlace] != null) { player.QuickSpawnItem(player.GetModPlayer<EngineerPlayer>().attachments[EA.attachmentPlace]); }
                player.GetModPlayer<EngineerPlayer>().attachments[EA.attachmentPlace] = mouseItemClone;
                itemSlots[EA.attachmentPlace] = player.GetModPlayer<EngineerPlayer>().attachments[EA.attachmentPlace];
            }
            else { killItem = false; }
        }
        private void OnRightMB(UIMouseEvent evt, UIElement listeningElement)
        {
            if (!(Main.playerInventory))
            {
                return;
            }
            for (int i = 0; i < 6; i++)
            {
                if (listeningElement == slots[i])
                {
                    itemSlots[i] = player.GetModPlayer<EngineerPlayer>().attachments[i];
                    if (itemSlots[i] != null)
                    {
                        player.QuickSpawnItem(player.GetModPlayer<EngineerPlayer>().attachments[i]);
                        player.GetModPlayer<EngineerPlayer>().attachments[i] = null;
                        itemSlots[i] = player.GetModPlayer<EngineerPlayer>().attachments[i];
                    }
                    break;
                }
            }
        }
        public override void Update(GameTime gameTime)
        {
            player = Main.LocalPlayer;
            base.Update(gameTime);
            itemSlots = player.GetModPlayer<EngineerPlayer>().attachments;
            if (killItem && Main.mouseItem.type == ItemID.None && player.inventory[58].type == ItemID.None) { killItem = false; }
            if (killItem) { Main.mouseItem.SetDefaults(); player.inventory[58].SetDefaults(); }
        }
    }
}