﻿using System.Collections.Generic;
using System.Linq;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using EngineerClassMod.Items.EngineerClass.Attachments;

namespace EngineerClassMod.Items.EngineerClass.Weapons
{
    // This class handles everything for our custom damage class
    // Any class that we wish to be using our custom damage class will derive from this class, instead of ModItem
    public abstract class EngineerWeapon : ModItem
    {
        public override bool CloneNewInstances => true;
        public bool noAttachments = false;
        public int type = 0;
        public const short Rifle = 0;
        public const short ChainSaw = 1;
        public const short Drone = 2;
        public const short Other = -1;

        public int numBullets = 1;
        public float attackSpeed;
        public float baseAttackSpeed;
        public int baseDamage;
        public int damage;
        public float baseSpread;
        public float spread;
        public float damageMult = 1f;
        public float damageAdd = 0f;
        public float damageFlat = 0f;
        public int Crit = 0;
        public int Pierce = 1;
        public int ammoConsumeChance;
        private bool didConsumeAmmo;
        public int projType;
        public override void HoldItem(Player player) {

            
            if (!noAttachments)
            {
                ammoConsumeChance = 20;
                numBullets = 1;
                attackSpeed = baseAttackSpeed;
                damage = baseDamage;
                spread = baseSpread;
                damageMult = 1f;
                damageAdd = 0f;
                damageFlat = 0f;
                Crit = 0;
                projType = mod.ProjectileType("EngineerBullet");
                Pierce = 1;
                if (type == Rifle)
                {
                    for (int i = 0; i < 6; i++)
                    {
                        if (player.GetModPlayer<EngineerPlayer>().attachments[i] != null)
                        {
                            ModItem Mi = player.GetModPlayer<EngineerPlayer>().attachments[i].modItem;
                            if (Mi != null && Mi as EngineerAttachments != null)
                            {
                                EngineerAttachments ea = player.GetModPlayer<EngineerPlayer>().attachments[i].modItem as EngineerAttachments;
                                numBullets += ea.numBullets;
                                attackSpeed /= ea.attackSpeedIncrease;
                                damageMult += ea.damageMultIncrease;
                                damageFlat += ea.damageFlatIncrease;
                                damageAdd += ea.damageAddIncrease;
                                if (i == 1 && ea.projType != -1)
                                {
                                    projType = ea.projType;
                                }
                                Crit += ea.CritInc;
                                Pierce += ea.Pierce;
                                ammoConsumeChance += ea.ChanceNotToConsumeAmmo;
                                spread *= ea.spreadMult;




                            }
                        }


                    }
                }
                spread *= player.GetModPlayer<EngineerPlayer>().spread;
                if (spread < 0) { spread = 0; }
                attackSpeed *= player.GetModPlayer<EngineerPlayer>().fireRate;
                int AttackSpeedBonus = 1;
                for (int i = 0; i < AttackSpeedBonus; i++)
                {
                    if ((attackSpeed /= 0.5f) < 2) { numBullets += 1; AttackSpeedBonus += 1; }
                }
                if (4 + player.GetModPlayer<EngineerPlayer>().engineerCrit + Crit > 100) { damageFlat += (4 + player.GetModPlayer<EngineerPlayer>().engineerCrit + Crit - 100); Crit = 96 - player.GetModPlayer<EngineerPlayer>().engineerCrit; }
            }

            
            


        }
        
        public override float UseTimeMultiplier(Player player)
        {

            return attackSpeed / baseAttackSpeed;

        }
        public override float MeleeSpeedMultiplier(Player player)
        {

            return attackSpeed / baseAttackSpeed;

        }


        // Custom items should override this to set their defaults
        public virtual void SafeSetDefaults()
        {
            
        }

        // By making the override sealed, we prevent derived classes from further overriding the method and enforcing the use of SafeSetDefaults()
        // We do this to ensure that the vanilla damage types are always set to false, which makes the custom damage type work
        public sealed override void SetDefaults()
        {
            SafeSetDefaults();
            // all vanilla damage types must be false for custom damage types to work
            item.melee = false;
            item.ranged = false;
            item.magic = false;
            item.thrown = false;
            item.summon = false;
            item.shoot = ProjectileID.WoodenArrowFriendly;
            item.UseSound = SoundID.Item11;
        }

        // As a modder, you could also opt to make these overrides also sealed. Up to the modder
        public override void ModifyWeaponDamage(Player player, ref float add, ref float mult, ref float flat)
        {
            add += EngineerPlayer.ModPlayer(player).engineerDamageAdd;
            mult *= EngineerPlayer.ModPlayer(player).engineerDamageMult;
            add += damageAdd;
            mult *= damageMult;
            flat += damageFlat;
        }

        public override void GetWeaponKnockback(Player player, ref float knockback)
        {
            // Adds knockback bonuses
            knockback += EngineerPlayer.ModPlayer(player).engineerKnockback;
        }

        public override void GetWeaponCrit(Player player, ref int crit)
        {
            // Adds crit bonuses
            crit += 4;
            crit += EngineerPlayer.ModPlayer(player).engineerCrit;
            crit += Crit;
        }

        // Because we want the damage tooltip to show our custom damage, we need to modify it
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            // Get the vanilla damage tooltip
            TooltipLine tt = tooltips.FirstOrDefault(x => x.Name == "Damage" && x.mod == "Terraria");
            if (tt != null)
            {
                // We want to grab the last word of the tooltip, which is the translated word for 'damage' (depending on what language the player is using)
                // So we split the string by whitespace, and grab the last word from the returned arrays to get the damage word, and the first to get the damage shown in the tooltip
                string[] splitText = tt.text.Split(' ');
                string damageValue = splitText.First();
                string damageWord = splitText.Last();
                // Change the tooltip text
                tt.text = damageValue + " engineer " + damageWord;
            }

           
        }
        public override bool ConsumeAmmo(Player player)
        {
            didConsumeAmmo = true;
            if (Main.rand.Next(0, 100) <= ammoConsumeChance)
            { didConsumeAmmo = false; return false; }
            return true;
        
        
        }

        // Make sure you can't use the item if you don't have enough resource and then use 10 resource otherwise.
        public override bool CanUseItem(Player player)
        {
            var EngineerPlayer = player.GetModPlayer<EngineerPlayer>();
            if (player.altFunctionUse == 2) { EngineerPlayer.Reload = true; return false; }
            if (player.GetModPlayer<EngineerPlayer>().EngineerWeapon == false) { return false; }
                if (EngineerPlayer.BulletsCurrent >= 1 && EngineerPlayer.Reload == false)
            {
                if (didConsumeAmmo)
                {
                    EngineerPlayer.BulletsCurrent -= 1;
                }
                return true;
                
            }
            return false;
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {

            Vector2 muzzleOffset = Vector2.Normalize(new Vector2(speedX, speedY)) * 35f;
            if (Collision.CanHit(position, 0, 0, position + muzzleOffset, 0, 0))
            {
                position += muzzleOffset;
            }
            int RealCrit = 4 + player.GetModPlayer<EngineerPlayer>().engineerCrit + Crit;
            for (int i = 0; i < numBullets; i++)
            {
                if (projType == mod.ProjectileType("EngineerBullet"))
                {
                    Projectile.NewProjectile(position, new Vector2(speedX + Main.rand.NextFloat(-spread / 2, spread / 2), speedY + Main.rand.NextFloat(-spread, spread)), projType, damage, knockBack, player.whoAmI, Pierce, RealCrit);
                }
                else { Projectile.NewProjectile(position, new Vector2(speedX + Main.rand.NextFloat(-spread / 2, spread / 2), speedY + Main.rand.NextFloat(-spread, spread)), projType, damage, knockBack, player.whoAmI); }



            }





            return false;
        }
        public override bool AltFunctionUse(Player player)
        { return true; }





    }
}
