﻿using EngineerClassMod.Projectiles;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using Terraria.ModLoader;

namespace EngineerClassMod.Items.EngineerClass.Attachments
{
    // This class handles everything for our custom damage class
    // Any class that we wish to be using our custom damage class will derive from this class, instead of ModItem
   
    public abstract class EngineerAttachments : ModItem
    {
        public override bool CloneNewInstances => true;
        public int attachmentFor = 0;
        
        public const short Rifle = 0;
        public const short Chainsaw = 1;
        public const short Drone = 2;
        public int attachmentPlace = 0;
        public const short isGunBody = 0;
        public const short isGunBarrel = 1;
        public const short isGunScope = 2;       
        public const short isGunGrip = 3;
        public const short isGunMag = 4;
        public const short isGunChamber = 5;
        public bool shouldOffset = false;
        public Vector2 drawOffset;
        public int numBullets = 0;
        public float attackSpeedIncrease = 1f;
        public float damageMultIncrease = 0f;
        public float damageAddIncrease = 0f;
        public float damageFlatIncrease = 0f;
        public int projType = -1;
        public int CritInc = 0;
        public int Pierce = 0;
        public int ChanceNotToConsumeAmmo = 0;
        public float spreadMult = 1f;


    }
}