﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;

namespace EngineerClassMod.Items.EngineerClass.Attachments
{
    public class GunScope2 : EngineerAttachments
    {
        
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Light Scope");
            Tooltip.SetDefault("Increases accuracy and crit chance slightly");
            

        }
        public override void SetDefaults()
        {
            item.width = 27;
            item.height = 14;
            item.maxStack = 1;
            item.rare = 4;
            item.value = 100;
            attachmentPlace = isGunScope;
            
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod.ItemType("GoldenScrew"), 12);
            recipe.AddIngredient(mod.ItemType("GoldenPlate"), 15);
            recipe.AddIngredient(mod.ItemType("GoldenCog"), 10);
            recipe.AddIngredient(mod.ItemType("GoldenPipe"), 14);
            recipe.AddTile(TileID.WorkBenches);


            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
