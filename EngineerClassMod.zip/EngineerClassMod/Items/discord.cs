﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;

namespace EngineerClassMod.Items
{
    public class discord : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Discord link, join plz");
            Tooltip.SetDefault("discord.gg/qcaTWB9 For join easy, see the mod description");

        }
        public override void SetDefaults()
        {
            item.width = 24;
            item.height = 24;
            item.maxStack = 999;
            item.rare = 7;
            item.value = 50;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.StoneBlock, 1);

            recipe.SetResult(this);
            recipe.AddRecipe();

        }
    }

}