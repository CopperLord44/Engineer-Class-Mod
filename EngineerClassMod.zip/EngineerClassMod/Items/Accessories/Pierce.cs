﻿using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using EngineerClassMod.Items.EngineerClass;

namespace EngineerClassMod.Items.Accessories
{
    
    public class Pierce : ModItem
    {


        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Pierce bullets");
            Tooltip.SetDefault("The user get +15 amor penetration but decress the reload speed a lot");
        }

        public override void SetDefaults()
        {
            item.width = 32;
            item.height = 32;
            item.value = 4000;
            item.rare = ItemRarityID.Green;
            item.accessory = true;

        }
        public override void UpdateAccessory(Player player, bool hideVisual)
        {

            player.armorPenetration += 15;
            player.GetModPlayer<EngineerPlayer>().ReloadCounter2 = (int)(player.GetModPlayer<EngineerPlayer>().ReloadCounter2*2.80);
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Harpoon, 15);
            recipe.AddIngredient(mod.ItemType("GoldenScrew"), 75);
            recipe.AddIngredient(mod.ItemType("BulletChain"),3);
            
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}