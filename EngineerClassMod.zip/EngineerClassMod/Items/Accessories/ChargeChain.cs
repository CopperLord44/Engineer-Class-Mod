﻿using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using EngineerClassMod.Items.EngineerClass;

namespace EngineerClassMod.Items.Accessories
{
    
    public class ChargeChain : ModItem
    {


        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Fast-Charge Chain");
            Tooltip.SetDefault("Increases clip size by 5 and incress the player speed by 25%");
        }

        public override void SetDefaults()
        {
            item.width = 32;
            item.height = 32;
            item.value = 4000;
            item.rare = ItemRarityID.Green;
            item.accessory = true;

        }
        public override void UpdateAccessory(Player player, bool hideVisual)
        {

            player.GetModPlayer<EngineerPlayer>().MaxBullets2 += 5;
            player.runAcceleration *= 1.25f;
            player.maxRunSpeed *= 1.25f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.TitaniumBar, 20);
            recipe.AddIngredient(ItemID.EmptyBullet, 50);
            recipe.AddIngredient(mod.ItemType("BulletChain"),5);
            
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}